#  goldfish > 2025-09-29 11:59pm
https://universe.roboflow.com/kheng-kok-mar-504hc/goldfish-w7mkw-mlkc6

Provided by a Roboflow user
License: CC BY 4.0

