# gold-fish > 2023-08-29 9:24pm
https://universe.roboflow.com/ton-o/gold-fish-oxtxs

Provided by a Roboflow user
License: CC BY 4.0

